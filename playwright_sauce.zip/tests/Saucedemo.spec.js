import { test, expect } from '@playwright/test';
import { chromium, webkit, firefox } from '@playwright/test';
import { Saucedemologinpage } from '../pages/saucedemologinpage';
import { Saucedemo } from '../datatables/json/constants.json';
import { Saucedemohomepage } from '../pages/Saucedemohomepage';

import fs from 'fs';
import path from 'path';
import { parse } from 'csv-parse/sync';

console.log(__dirname);

//var tmpModulePath1 = 'D:';

const records = parse(

    fs.readFileSync(path.join(__dirname, '../datatables/csv/testdata.csv')),
    {
        columns: true,
        skip_empty_lines: true,

    });




let saucedemologinpage, saucedemohomepage;

for (const record of records) {

    test('Launching Saucedemo website and performing required actions ${record.testcaseid}', async ({ page }) => {

        test.setTimeout(300000);
        const browser = await chromium.launch({ headless: false, channel: 'chrome' });
        const context = await browser.newContext();



        saucedemologinpage = new Saucedemologinpage(page);

        saucedemohomepage = new Saucedemohomepage(page);



        console.log(records.url);

        await saucedemologinpage.LaunchSaucedemologinpage(record.url);


        await page.waitForTimeout(5000);

        await saucedemologinpage.enterusername(record.username);

        await page.waitForTimeout(5000);

        await saucedemologinpage.enterpassword(record.password);

        await page.waitForTimeout(5000);

        await saucedemologinpage.clickloginbtn();

        await page.waitForTimeout(5000);

        //assertion whether first product is visible and then adding the product to cart

        await expect.soft(await saucedemohomepage.Desiredproduct(record.product1)).toBeVisible();

        await page.waitForTimeout(5000);


        await saucedemohomepage.clickDesiredproduct(record.product1);

        await page.waitForTimeout(5000);

        await saucedemohomepage.clickaddtocartbtninpage();

        await page.waitForTimeout(5000);

        await saucedemohomepage.Backtoproductbutton();

        await page.waitForTimeout(5000);

        //assertion whether second product is visible and then adding the product to cart

        await expect.soft(await saucedemohomepage.Desiredproduct(record.product2)).toBeVisible();

        await page.waitForTimeout(5000);


        await saucedemohomepage.clickDesiredproduct(record.product2);

        await page.waitForTimeout(5000);

        await saucedemohomepage.clickaddtocartbtninpage();

        await page.waitForTimeout(5000);

        await saucedemohomepage.Backtoproductbutton();

        await page.waitForTimeout(5000);

        //assertion whether third product is visible and then adding the product to cart

        await expect.soft(await saucedemohomepage.Desiredproduct(record.product3)).toBeVisible();

        await page.waitForTimeout(5000);


        await saucedemohomepage.clickDesiredproduct(record.product3);

        await page.waitForTimeout(5000);

        await saucedemohomepage.clickaddtocartbtninpage();

        await page.waitForTimeout(5000);

        await saucedemohomepage.Backtoproductbutton();

        await page.waitForTimeout(5000);

        //assertion whether fourth product is visible

        await expect.soft(await saucedemohomepage.Desiredproduct(record.product4)).toBeVisible();

        await page.waitForTimeout(5000);

        //clicking add to cart button

        await saucedemohomepage.Addtocartbtntoprightcorner();

        await page.waitForTimeout(5000);

        //remove the mentioned product 

        await saucedemohomepage.clickDesiredproduct(record.product2);

        await page.waitForTimeout(5000);

        await saucedemohomepage.clickremovebtn();

        await page.waitForTimeout(5000);

        await saucedemohomepage.Backtoproductbutton();

        await page.waitForTimeout(5000);

        //click checkout btn after removing the mentioned product

        await saucedemohomepage.Addtocartbtntoprightcorner();

        await page.waitForTimeout(5000);

        await saucedemohomepage.clickcheckoutbtn();

        await page.waitForTimeout(5000);

        await saucedemohomepage.enterfirstname(record.firstname);

        await page.waitForTimeout(5000);

        await saucedemohomepage.enterlastname(record.lastname);

        await page.waitForTimeout(5000);

        await saucedemohomepage.enterpostalcode(record.postalcode);

        await page.waitForTimeout(5000);



        await saucedemohomepage.clickcontinuebtn();

        await page.waitForTimeout(5000);

        //remove another mentioned product in checkout

        await saucedemohomepage.clickDesiredproduct(record.product3);

        await page.waitForTimeout(5000);

        await saucedemohomepage.clickremovebtn();

        await page.waitForTimeout(5000);

        await saucedemohomepage.Backtoproductbutton();

        await page.waitForTimeout(5000);

        //click checkout btn after removing the mentioned product

        await saucedemohomepage.Addtocartbtntoprightcorner();

        await page.waitForTimeout(5000);

        await saucedemohomepage.clickcheckoutbtn();

        await page.waitForTimeout(5000);

        await saucedemohomepage.enterfirstname(record.firstname);

        await page.waitForTimeout(5000);

        await saucedemohomepage.enterlastname(record.lastname);

        await page.waitForTimeout(5000);

        await saucedemohomepage.enterpostalcode(record.postalcode);

        await page.waitForTimeout(5000);



        await saucedemohomepage.clickcontinuebtn();

        await page.waitForTimeout(5000);



        let totalprice = await (await saucedemohomepage.totalpriceotalprice()).textContent();

        let totalpricefinal = totalprice.split('$');

        let totalpricefinalasinterger = Number(totalpricefinal[1]);

        console.log("Total price is " + totalpricefinalasinterger);

        if (totalpricefinalasinterger < 40) {
            await saucedemohomepage.clickfinishbtn();
        }
        else if (totalpricefinalasinterger > 40){
            await saucedemohomepage.clickcancelbtn();
        }
        else{
            console.log('out of bound exception');
        }

        await page.waitForTimeout(5000);

        await expect.soft(await saucedemohomepage.Thankyoutext()).toBeVisible();

        await saucedemohomepage.Backtoproductbutton();

        await page.waitForTimeout(5000);

        await saucedemohomepage.clickburgermenu();

        await page.waitForTimeout(5000);

        await saucedemohomepage.clicklogoutbtn();




        await page.waitForTimeout(5000);











    })

}
